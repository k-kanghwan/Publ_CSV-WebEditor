DEBUG_MODE = True


from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import pandas as pd
import os
import sys
import uvicorn
import tkinter as tk
from tkinter import filedialog
from fastapi.concurrency import run_in_threadpool
from pandas.errors import EmptyDataError

app = FastAPI()

# Resolve base path for both source and frozen (PyInstaller) builds
if getattr(sys, "frozen", False):
    base_path = sys._MEIPASS  # type: ignore[attr-defined]
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

DATA_DIR = r""
STATIC_DIR = os.path.join(base_path, "static")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
async def root():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


@app.get("/favicon.ico")
async def favicon():
    return FileResponse(os.path.join(STATIC_DIR, "favicon.svg"))


@app.get("/files")
async def list_files():
    files = [f for f in os.listdir(DATA_DIR) if f.endswith(".csv")]
    return JSONResponse(files)


@app.get("/current_data_dir")
async def current_data_dir():
    return JSONResponse({"data_dir": DATA_DIR})


@app.get("/load/{filename}")
async def load_file(filename: str):
    path = os.path.join(DATA_DIR, filename)
    if not os.path.exists(path):
        return JSONResponse({"error": "File not found"}, status_code=404)
    try:
        df = pd.read_csv(path)
        return JSONResponse(df.to_dict(orient="records"))
    except EmptyDataError:
        # Empty file: return empty list so frontend can show a blank table
        return JSONResponse([])


@app.post("/set_data_dir/{new_dir}")
async def set_data_dir(new_dir: str):
    global DATA_DIR
    if new_dir and os.path.isdir(new_dir):
        DATA_DIR = new_dir
        return JSONResponse({"status": "success", "data_dir": DATA_DIR})
    else:
        return JSONResponse({"error": "Invalid directory"}, status_code=400)


@app.post("/save/{filename}")
async def save_file(filename: str, request: Request):
    path = os.path.join(DATA_DIR, filename)
    data = await request.json()
    df = pd.DataFrame(data)
    df.to_csv(path, index=False, encoding="utf-8-sig")
    return JSONResponse({"status": "success"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run("CsvEditor:app", host="127.0.0.1", port=port, reload=DEBUG_MODE)
